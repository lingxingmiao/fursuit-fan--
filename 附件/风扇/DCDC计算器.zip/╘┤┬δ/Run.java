import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

//Run必须为文件名(请不要包含后缀)
public class Run {

    public static void main(String[] args) {
        Properties prop = new Properties();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream("config.cfg");
            prop.load(fis);
            double vout = Double.parseDouble(prop.getProperty("vout"));
            double vref = Double.parseDouble(prop.getProperty("vref"));
            String r1ValuesStr = prop.getProperty("r1.values");
            String[] r1ValuesArray = r1ValuesStr.split(",");
            ArrayList<Double> R1 = new ArrayList<>();
            for (String value : r1ValuesArray) {
                R1.add(Double.parseDouble(value.trim()));
            }
            ArrayList<Double> R2 = new ArrayList<>();
            for (Double r1 : R1) {
                // 更改算法 r1为R1电阻 vref为参考电压 vout为输出电压
                double r2 = (r1 * vref) / (vout - vref);

                R2.add(r2);
            }
            for (int i = 0; i < R2.size(); i++) {
                System.out.println("R2:" + R2.get(i) + " R1:" + R1.get(i));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }}

    
    
    
    
    
    
    

    
    

    

    

    

    
    
    
