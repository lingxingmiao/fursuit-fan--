cd ./
java Run
pause