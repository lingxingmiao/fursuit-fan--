cd ./
java run
pause